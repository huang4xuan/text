项目简介
项目来源于：https://gitee.com/z77z/StuSystem
本系统是基于JSP+SSM+Mysql实现的学生成绩管理系统。主要实现的功能有教师管理、学生管理、课程管理、学生成绩管理。

难度等级：中等

技术栈
编辑器
Eclipse Version: 2020-03 (4.15.0)

前端技术
基础：html+css+JavaScript

框架：JQuery+H-ui

后端技术
Spring+SpringMVC+mybatis

模板引擎：JSP

数据库：mysql 5.7.27（个人测试使用）

jdk版本：1.8.0_251（个人测试使用）

tomcat版本：8.5.34（个人测试使用）

数据库连接池：druid

本地运行
Eclipse环境准备
1.eclipse新增jdk


eclipse新增jdk
2.eclipse新增tomcat

导入项目
若有疑惑可查看视频版本。

SSM学生成绩管理系统
1.下载zip直接解压或安装git后执行克隆命令。

git clone https://gitee.com/z77z/StuSystem.git
2.使用eclipse导入项目，配置jdk、tomcat和所需jar包。 项目所依赖jar包在WebContent/WEB-INF/lib文件夹下。

3.打开Navicat For Mysql，创建stusystem 数据库，并运行stusystem.sql文件。

4.修改src\demo.properties中数据库相关的内容。

5.发布到tomcat中，具体访问链接看tomcat配置，若未修改则http://localhost:8080/StuSystem/为登录页面。

该系统分为3种账号。

管理员初始账号：10003 系统管理员初始密码：admin

教师初始账号：20001 教师初始密码：1234

学生初始账号: 10001 学生初始密码：1234

注意
•该项目未声明mysql、jdk、tomcat使用版本，以上版本号均为个人测试使用版本。

•注意修改src\demo.properties中数据库相关的内容。

项目截图








